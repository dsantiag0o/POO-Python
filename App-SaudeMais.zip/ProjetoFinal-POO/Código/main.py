from Paciente import Paciente
from tkinter import *

class Application:
    def __init__(self, master=None):
        self.fonte = ("Verdana", "12")

        self.container1 = Frame(master)
        self.container1["pady"] = 10
        self.container1.pack()
        self.container1.configure(background='#bdecb6')

        self.container2 = Frame(master)
        self.container2["padx"] = 20
        self.container2["pady"] = 5
        self.container2.pack()
        self.container2.configure(background='#bdecb6')

        self.container0 = Frame(master)
        self.container0["pady"] = 10
        self.container0["padx"] = 20
        self.container0.pack()
        self.container0.configure(background='#bdecb6')

        self.container3 = Frame(master)
        self.container3["padx"] = 20
        self.container3["pady"] = 5
        self.container3.pack()
        self.container3.configure(background='#bdecb6')

        self.container4 = Frame(master)
        self.container4["padx"] = 20
        self.container4["pady"] = 5
        self.container4.pack()
        self.container4.configure(background='#bdecb6')

        self.container5 = Frame(master)
        self.container5["padx"] = 20
        self.container5["pady"] = 5
        self.container5.pack()
        self.container5.configure(background='#bdecb6')

        self.container6 = Frame(master)
        self.container6["padx"] = 20
        self.container6["pady"] = 5
        self.container6.pack()
        self.container6.configure(background='#bdecb6')

        self.container7 = Frame(master)
        self.container7["padx"] = 20
        self.container7["pady"] = 5
        self.container7.pack()
        self.container7.configure(background='#bdecb6')

        self.container8 = Frame(master)
        self.container8["padx"] = 20
        self.container8["pady"] = 10
        self.container8.pack()
        self.container8.configure(background='#bdecb6')

        self.container9 = Frame(master)
        self.container9["pady"] = 15
        self.container9.pack()
        self.container9.configure(background='#bdecb6')

        self.titulo = Label(self.container1, text="CLÍNICA SAÚDE MAIS +")
        self.titulo["font"] = ("Impact", "22")
        self.titulo.pack ()
        self.titulo.configure(background='#bdecb6')

        self.titulo = Label(self.container1, text="Mais saúde para você!\n")
        self.titulo["font"] = ("Arial", "11","italic")
        self.titulo.pack ()
        self.titulo.configure(background='#bdecb6')

        self.titulo = Label(self.container1, text="Informe os dados do Paciente :")
        self.titulo["font"] = ("Arial", "16", "bold")
        self.titulo.pack ()
        self.titulo.configure(background='#bdecb6')

        self.lblId = Label(self.container2,
        text="id:", font=self.fonte, width=10)
        self.lblId.pack(side=LEFT)
        self.lblId.configure(background='#bdecb6')

        self.txtId = Entry(self.container2)
        self.txtId["width"] = 10
        self.txtId["font"] = self.fonte
        self.txtId.pack(side=LEFT)

        self.btnBuscar = Button(self.container2, text="Buscar",
        font=self.fonte, width=10)
        self.btnBuscar["command"] = self.buscarPaciente
        self.btnBuscar.pack(side=RIGHT)

        self.lblCpfBuscar = Label(self.container0,
        text="Pelo CPF :", font=self.fonte, width=10)
        self.lblCpfBuscar.pack(side=LEFT)
        self.lblCpfBuscar.configure(background='#bdecb6')

        self.txtCpfBuscar = Entry(self.container0)
        self.txtCpfBuscar["width"] = 20
        self.txtCpfBuscar["font"] = self.fonte
        self.txtCpfBuscar.pack(side=LEFT)

        self.btnBuscarCpf = Button(self.container0, text="Buscar",
        font=self.fonte, width=10)
        self.btnBuscarCpf["command"] = self.buscarPacienteCPF
        self.btnBuscarCpf.pack(side=RIGHT)

        self.lblNome = Label(self.container3, text="Nome:",
        font=self.fonte, width=10)
        self.lblNome.pack(side=LEFT)
        self.lblNome.configure(background='#bdecb6')

        self.txtNome = Entry(self.container3)
        self.txtNome["width"] = 25
        self.txtNome["font"] = self.fonte
        self.txtNome.pack(side=LEFT)

        self.lblTelefone = Label(self.container4, text="Telefone:",
        font=self.fonte, width=10)
        self.lblTelefone.pack(side=LEFT)
        self.lblTelefone.configure(background='#bdecb6')

        self.txtTelefone = Entry(self.container4)
        self.txtTelefone["width"] = 25
        self.txtTelefone["font"] = self.fonte
        self.txtTelefone.pack(side=LEFT)

        self.lblEmail= Label(self.container5, text="E-mail:",
        font=self.fonte, width=10)
        self.lblEmail.pack(side=LEFT)
        self.lblEmail.configure(background='#bdecb6')

        self.txtEmail = Entry(self.container5)
        self.txtEmail["width"] = 25
        self.txtEmail["font"] = self.fonte
        self.txtEmail.pack(side=LEFT)

        self.lblEndereco= Label(self.container6, text="Endereço:",
        font=self.fonte, width=10)
        self.lblEndereco.pack(side=LEFT)
        self.lblEndereco.configure(background='#bdecb6')

        self.txtEndereco = Entry(self.container6)
        self.txtEndereco["width"] = 25
        self.txtEndereco["font"] = self.fonte
        self.txtEndereco.pack(side=LEFT)

        self.lblCpf= Label(self.container7, text="CPF:",
        font=self.fonte, width=10)
        self.lblCpf.pack(side=LEFT)
        self.lblCpf.configure(background='#bdecb6')

        self.txtCpf = Entry(self.container7)
        self.txtCpf["width"] = 25
        ##self.txtCpf["show"] = "*"
        self.txtCpf["font"] = self.fonte
        self.txtCpf.pack(side=LEFT)

        self.bntInsert = Button(self.container8, text="Inserir",
        font=self.fonte, width=12)
        self.bntInsert["command"] = self.inserirPaciente
        self.bntInsert.pack (side=LEFT)

        self.bntAlterar = Button(self.container8, text="Alterar",
        font=self.fonte, width=12)
        self.bntAlterar["command"] = self.alterarPaciente
        self.bntAlterar.pack (side=LEFT)

        self.bntExcluir = Button(self.container8, text="Excluir",
        font=self.fonte, width=12)
        self.bntExcluir["command"] = self.excluirPaciente
        self.bntExcluir.pack(side=LEFT)

        self.lblmsg = Label(self.container9, text="")
        self.lblmsg["font"] = ("Impact", "12")
        self.lblmsg.pack()
        self.lblmsg.configure(background='#bdecb6')


    def inserirPaciente(self):
        p = Paciente()

        p.nome = self.txtNome.get()
        p.telefone = self.txtTelefone.get()
        p.email = self.txtEmail.get()
        p.endereco = self.txtEndereco.get()
        p.cpf = self.txtCpf.get()

        self.lblmsg["text"] = p.insertPaciente()

        self.txtId.delete(0, END)
        self.txtNome.delete(0, END)
        self.txtTelefone.delete(0, END)
        self.txtEmail.delete(0, END)
        self.txtEndereco.delete(0, END)
        self.txtCpf.delete(0, END)



    def alterarPaciente(self):
        p = Paciente()

        p.idPaciente = self.txtId.get()
        p.nome = self.txtNome.get()
        p.telefone = self.txtTelefone.get()
        p.email = self.txtEmail.get()
        p.endereco = self.txtEndereco.get()
        p.senha = self.txtCpf.get()

        self.lblmsg["text"] = p.updatePaciente()

        self.txtId.delete(0, END)
        self.txtNome.delete(0, END)
        self.txtTelefone.delete(0, END)
        self.txtEmail.delete(0, END)
        self.txtEndereco.delete(0, END)
        self.txtCpf.delete(0, END)



    def excluirPaciente(self):
        p = Paciente()

        p.idPaciente = self.txtId.get()

        self.lblmsg["text"] = p.deletePaciente()

        self.txtId.delete(0, END)
        self.txtNome.delete(0, END)
        self.txtTelefone.delete(0, END)
        self.txtEmail.delete(0, END)
        self.txtEndereco.delete(0, END)
        self.txtCpf.delete(0, END)


    def buscarPaciente(self):
        p = Paciente()

        idPaciente = self.txtId.get()

        self.lblmsg["text"] = p.selectPaciente(idPaciente)

        self.txtId.delete(0, END)
        self.txtId.insert(INSERT, p.idPaciente)

        self.txtNome.delete(0, END)
        self.txtNome.insert(INSERT, p.nome)

        self.txtTelefone.delete(0, END)
        self.txtTelefone.insert(INSERT,p.telefone)

        self.txtEmail.delete(0, END)
        self.txtEmail.insert(INSERT, p.email)

        self.txtEndereco.delete(0, END)
        self.txtEndereco.insert(INSERT, p.endereco)

        self.txtCpf.delete(0, END)
        self.txtCpf.insert(INSERT,p.cpf)

    def buscarPacienteCPF(self):
            p = Paciente()

            cpfBuscar = "'"+self.txtCpfBuscar.get()+"'"

            self.lblmsg["text"] = p.selectPacienteCPF(cpfBuscar)

            self.txtId.delete(0, END)
            self.txtId.insert(INSERT, p.idPaciente)

            self.txtNome.delete(0, END)
            self.txtNome.insert(INSERT, p.nome)

            self.txtTelefone.delete(0, END)
            self.txtTelefone.insert(INSERT,p.telefone)

            self.txtEmail.delete(0, END)
            self.txtEmail.insert(INSERT, p.email)

            self.txtEndereco.delete(0, END)
            self.txtEndereco.insert(INSERT, p.endereco)

            self.txtCpf.delete(0, END)
            self.txtCpf.insert(INSERT,p.cpf)


root = Tk()
root.geometry('1000x500')
root.title('Clínica Saúde Mais')
root.configure(background='#bdecb6')
Application(root)
root.mainloop()