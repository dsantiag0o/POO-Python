from Banco import Banco

class Paciente():

    def __init__(self, idPaciente = 0, nome = "", telefone = "", email = "", endereco = "", cpf = ""):
        self.info = {}
        self.idPaciente = idPaciente
        self.nome = nome
        self.telefone = telefone
        self.email = email
        self.endereco = endereco
        self.cpf = cpf

    def insertPaciente(self):

        banco = Banco()
        try:

            c = banco.conexao.cursor()

            c.execute("insert into paciente (nome, telefone, email, endereco, cpf) values('" + self.nome + "', '" +self.telefone + "', '" + self.email + "', '" +self.endereco + "', '" + self.cpf + "' )")
            banco.conexao.commit()
            c.close()

            return "O paciente foi cadastrado com sucesso!"
        except:
            return "Ocorreu um erro na inserção do paciente..."


    def updatePaciente(self):

        banco = Banco()
        try:

            c = banco.conexao.cursor()

            c.execute("update paciente set nome = '" + self.nome + "', telefone = '" + self.telefone + "', email = '" + self.email +"', endereco = '" + self.endereco + "', cpf = '" + self.cpf +"' where idPaciente = " + self.idPaciente + " ")

            banco.conexao.commit()
            c.close()

            return "O paciente foi atualizado com sucesso!"
        except:
            return "Ocorreu um erro na alteração do paciente..."
    
    def deletePaciente(self):

        banco = Banco()
        try:

            c = banco.conexao.cursor()

            c.execute("delete from paciente where idPaciente = " + self.idPaciente + " ")

            banco.conexao.commit()
            c.close()

            return "O paciente foi excluído com sucesso!"
        except:
            return "Ocorreu um erro na exclusão do paciente"
    
    def selectPaciente(self, idPaciente):
        banco = Banco()
        try:

            c = banco.conexao.cursor()

            c.execute("select * from paciente where idPaciente = " + idPaciente + "  ")

            for linha in c:
                self.idPaciente = linha[0]
                self.nome = linha[1]
                self.telefone = linha[2]
                self.email = linha[3]
                self.endereco = linha[4]
                self.cpf = linha[5]

            c.close()

            return "Busca feita com sucesso!"
        except:
            return "Ocorreu um erro na busca do paciente"

    
    def selectPacienteCPF(self, cpfPaciente):
        str(cpfPaciente)
        banco = Banco()
        try:

            c = banco.conexao.cursor()

            c.execute("select * from paciente where cpf = "+cpfPaciente+"")

            for linha in c:
                self.idPaciente = linha[0]
                self.nome = linha[1]
                self.telefone = linha[2]
                self.email = linha[3]
                self.endereco = linha[4]
                self.cpf = linha[5]

            c.close()

            return "Busca feita com sucesso!"
        except:
            return "Ocorreu um erro na busca do paciente"